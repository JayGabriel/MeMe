//
//  CollectionViewController.swift
//  MeMe
//
//  Created by jay on 9/14/17.
//  Copyright © 2017 JayGabriel. All rights reserved.
//

import UIKit

class CollectionViewController: UICollectionViewController {
    
    // MARK: Properties
    var memes: [Meme]!
    
    var appDelegate: AppDelegate!
    
    // MARK: Outlets
    @IBOutlet weak var flowLayout: UICollectionViewFlowLayout!

    
    // MARK: View configuration
    override func viewDidLoad() {
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let space: CGFloat = 3.0
        let dimension = (view.frame.width - (2 * space)) / 3.0
        
        flowLayout.minimumInteritemSpacing = space
        flowLayout.minimumLineSpacing = space
        flowLayout.itemSize = CGSize(width: dimension, height: dimension)

    }
    
    override func viewWillAppear(_ animated: Bool) {
        memes = appDelegate.memes
        collectionView?.reloadData()
    }
    
    //MARK: Actions
    @IBAction func addButtonPressed(_ sender: UIBarButtonItem) {
        let CreateMemeView = storyboard?.instantiateViewController(withIdentifier: "CreateMeme") as! CreateMemeViewController
        present(CreateMemeView, animated: true, completion: nil)
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let detailView = storyboard?.instantiateViewController(withIdentifier: "detailView") as! ImageDetailViewController
        
        detailView.imageToSet = memes[indexPath.row].memedImage
        
        navigationController?.pushViewController(detailView, animated: true)
    }
    
    
    //MARK: Collection view configuration    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return memes.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
        func setupCellWith(meme: Meme) {
            cell.imageView.image = meme.originalImage
            cell.SubtitleTop.text = meme.topText
            cell.SubtitleBottom.text = meme.bottomText
            
            setMemeTextAttributes(textField: cell.SubtitleTop)
            setMemeTextAttributes(textField: cell.SubtitleBottom)
        }
        
        setupCellWith(meme: memes[indexPath.row])
        
        return cell
    }
    
    // MARK: Set text attributes
    func setMemeTextAttributes(textField: UITextField) {
        
        let memeTextAttributes:[String:Any] = [
            NSStrokeColorAttributeName: UIColor.black,
            NSForegroundColorAttributeName: UIColor.white,
            NSFontAttributeName: UIFont(name: "HelveticaNeue-CondensedBlack", size: 15)!,
            NSStrokeWidthAttributeName: Float(-4.0),
            ]
        
        textField.defaultTextAttributes = memeTextAttributes
        textField.textAlignment = .center
    }
    
}
