//
//  CreateMemeViewController.swift
//  MeMe
//
//  Created by jay on 8/22/17.
//  Copyright © 2017 JayGabriel. All rights reserved.
//
//  ** Updated 8/30/2017
//  - Fixed text field character formatting
//  - Simplified process or finding photo source type
//  - Seperated CreateMemeViewController class into extensions
//  - Moved Meme struct into a seperate file
//  - Simplified process of checking if a photo has been chosen
//  - Clarified process of moving the keyboard
//  - Fixed issue with stroke width

//  ** Updated 9/1/17
//  - Adjusted minimum font size to 17
//  - Moved setting text field delegates inside setMemetextAttributes
//  - Created a new method toggleNavBar
//  - Modified shifting the view up using a unary operator

// ** Updated 9/15/17 
//  - Detail view now supported
//  - Allowed table view to be editable: move and delete supported
//  - Simplified setting meme text attributes

// ** Updated 9/20/17
//  - Photo selector bar and activity bar are hidden when saving
//  - setupWithCell method added to configure table and collection views


import UIKit

class CreateMemeViewController: UIViewController {
    
    // MARK: Outlets
    
    // Image
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var photoSelectorBar: UIToolbar!
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    
    // Text fields
    @IBOutlet weak var topTextField: UITextField!
    @IBOutlet weak var bottomTextField: UITextField!
    
    // Actions
    @IBOutlet weak var actionBar: UIToolbar!
    @IBOutlet weak var shareButton: UIBarButtonItem!
    
    // MARK: Properties
    var photoChosen: Bool = false
    
    // MARK: View Methods
    override func viewDidLoad() {
        
        // Disable the camera if it is not available
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        super.viewDidLoad()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        setMemeTextAttributes(textField: topTextField)
        setMemeTextAttributes(textField: bottomTextField)
        
        // Check if a photo has been chosen
        shareButton.isEnabled = photoChosen
    }
    
    // Hide the status bar
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    @IBAction func shareButtonPressed(_ sender: UIBarButtonItem) {
        let memedImage = generateMemedImage()
        
        let controller = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
        
        present(controller, animated: true, completion: nil)
        
        controller.completionWithItemsHandler =  {
            (activity, success, items, error) in
            if(success && error == nil){
                // Success message
                let ac = UIAlertController(title: "Meme successfully saved!", message: nil, preferredStyle: .alert)
                ac.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))
                self.present(ac, animated: true, completion: nil)
                self.save()
            }
            else if (error != nil){
                // Error message
                let ac = UIAlertController(title: "Saving meme unsuccessful.", message: nil, preferredStyle: .alert)
                ac.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))
                self.present(ac, animated: true, completion: nil)
            }
        }
    }
    
    //MARK: Meme action related methods
    @IBAction func cancelPressed(_ sender: UIBarButtonItem) {
        imageView.image = nil
        topTextField.text?.removeAll()
        bottomTextField.text?.removeAll()
        photoChosen = false
        shareButton.isEnabled = false
        self.dismiss(animated: true, completion: nil)
    }
    
    func save() {
        let meme = Meme(topText: topTextField.text!, bottomText: bottomTextField.text!, originalImage: imageView.image!, memedImage: generateMemedImage())
        
        
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        appDelegate.memes.append(meme)
    }
    
    func generateMemedImage() -> UIImage {

        toggleNavBar(hide: true)
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        
        let memedImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        toggleNavBar(hide: false)
        
        return memedImage
    }
    
    func toggleNavBar(hide: Bool) {
        actionBar.isHidden = hide
        photoSelectorBar.isHidden = hide
    }
}

// MARK: UIImagePickerControllerDelegate
extension CreateMemeViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBAction func photoSelection(_ sender: UIBarButtonItem) {
        
        let picker = UIImagePickerController()
        picker.delegate = self
        
        if sender.tag == 0 {
            picker.sourceType = .camera
            present(picker, animated: true, completion: nil)
        } else if sender.tag == 1 {
            picker.sourceType = .photoLibrary
            present(picker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            imageView.image = image
            imageView.contentMode = .scaleAspectFit
            photoChosen = true
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }

}

// MARK: UITextFieldDelegate
extension CreateMemeViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if bottomTextField.isFirstResponder {
            subscribeToKeyboardNotifications()
        }
        subscribeToHidingKeyboardNotifications()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        textField.text = textField.text?.uppercased()
        
        // Unsubscribe from notifications
        unsubscribeFromKeyboardNotifications()
        unsubscribeFromHidingKeyboardNotifications()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        // Change all characters to uppercase during editing
        textField.text = (textField.text! as NSString).replacingCharacters(in: range, with: string.uppercased())
        return false
    }
    
    
    func getKeyboardHeight(_ notificaiton: Notification) -> CGFloat {
        
        let userInfo = notificaiton.userInfo
        let keyboardSize = userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue
        return keyboardSize.cgRectValue.height
    }
    
    // MARK: Show the keyboard
    func keyboardWillShow(_ notification: Notification) {
        view.frame.origin.y = -getKeyboardHeight(notification)
    }
    
    func subscribeToKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
    }
    
    // MARK: Hide the keyboard
    func keyboardWillHide(_ notification: Notification) {
        view.frame.origin.y = 0
    }
    
    func subscribeToHidingKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    
    func unsubscribeFromHidingKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    // MARK: Set text attributes
    func setMemeTextAttributes(textField: UITextField) {
        
        let memeTextAttributes:[String:Any] = [
            NSStrokeColorAttributeName: UIColor.black,
            NSForegroundColorAttributeName: UIColor.white,
            NSFontAttributeName: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
            NSStrokeWidthAttributeName: Float(-4.0),
            ]
        
        textField.delegate = self
        textField.defaultTextAttributes = memeTextAttributes
        textField.textAlignment = .center
    }
    
}

