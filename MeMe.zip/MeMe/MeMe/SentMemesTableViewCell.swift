//
//  SentMemesTableViewCell.swift
//  MeMe
//
//  Created by jay on 9/14/17.
//  Copyright © 2017 JayGabriel. All rights reserved.
//

import UIKit

class SentMemesTableViewCell: UITableViewCell {
   
    @IBOutlet weak var previewImage: UIImageView!
    @IBOutlet weak var SubtitleTop: UITextField!
    @IBOutlet weak var SubtitleBottom: UITextField!
    @IBOutlet weak var TitleTop: UILabel!
    @IBOutlet weak var TitleBottom: UILabel!
    
    
    override func willChangeValue(forKey key: String) {
        
            let memeTextAttributes:[String:Any] = [
                NSStrokeColorAttributeName: UIColor.black,
                NSForegroundColorAttributeName: UIColor.white,
                NSFontAttributeName: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
                NSStrokeWidthAttributeName: Float(-4.0),
                ]

            SubtitleTop.defaultTextAttributes = memeTextAttributes
            SubtitleBottom.defaultTextAttributes = memeTextAttributes
    }
   
}
