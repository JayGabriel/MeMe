//
//  CollectionViewCell.swift
//  MeMe
//
//  Created by jay on 9/14/17.
//  Copyright © 2017 JayGabriel. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var SubtitleTop: UITextField!
    @IBOutlet weak var SubtitleBottom: UITextField!
    
    
}
